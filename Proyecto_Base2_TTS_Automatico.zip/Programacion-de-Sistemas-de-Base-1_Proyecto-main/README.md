# Programación de Sistemas de Base 1 y 2 - Proyecto Integrador

Este repositorio contiene la evolución del proyecto integrador de **texto a voz con análisis léxico-sintáctico**.

## Contenido principal

- `Projecto/` - archivos originales de la etapa con ANTLR y sus artefactos generados.
- `traductor_texto_voz/` - versión lista para ejecutar en Python, con lexer, parser, AST, pruebas, salidas y documentación.
- `traductor_texto_voz/docs/reporte_final.pdf` - reporte final en el formato solicitado.

## Ejecución rápida

```bash
cd traductor_texto_voz
python main.py examples/entrada_demo.txt
python tests/test_runner.py
```

## Qué se entrega

- Código fuente del analizador.
- Gramática EaV2.
- Archivos de entrada de prueba.
- Archivos de salida generados por el traductor.
- Reporte PDF en la carpeta `docs`.
- Evidencia de funcionamiento lista para subirse a un repositorio.
