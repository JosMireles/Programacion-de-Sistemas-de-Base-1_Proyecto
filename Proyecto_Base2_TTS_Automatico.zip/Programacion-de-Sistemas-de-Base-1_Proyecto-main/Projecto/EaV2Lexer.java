// Generated from EaV2.g4 by ANTLR 4.13.2
import org.antlr.v4.runtime.Lexer;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.TokenStream;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.misc.*;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue", "this-escape"})
public class EaV2Lexer extends Lexer {
	static { RuntimeMetaData.checkVersion("4.13.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		LEXCL=1, REXCL=2, LQN=3, RQN=4, PUNCT=5, CONJ=6, NUMBER=7, WORD=8, WS=9;
	public static String[] channelNames = {
		"DEFAULT_TOKEN_CHANNEL", "HIDDEN"
	};

	public static String[] modeNames = {
		"DEFAULT_MODE"
	};

	private static String[] makeRuleNames() {
		return new String[] {
			"LEXCL", "REXCL", "LQN", "RQN", "PUNCT", "CONJ", "NUMBER", "WORD", "WS"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'\\u00A1'", "'!'", "'\\u00BF'", "'?'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "LEXCL", "REXCL", "LQN", "RQN", "PUNCT", "CONJ", "NUMBER", "WORD", 
			"WS"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}


	public EaV2Lexer(CharStream input) {
		super(input);
		_interp = new LexerATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@Override
	public String getGrammarFileName() { return "EaV2.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public String[] getChannelNames() { return channelNames; }

	@Override
	public String[] getModeNames() { return modeNames; }

	@Override
	public ATN getATN() { return _ATN; }

	public static final String _serializedATN =
		"\u0004\u0000\t5\u0006\uffff\uffff\u0002\u0000\u0007\u0000\u0002\u0001"+
		"\u0007\u0001\u0002\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004"+
		"\u0007\u0004\u0002\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007"+
		"\u0007\u0007\u0002\b\u0007\b\u0001\u0000\u0001\u0000\u0001\u0001\u0001"+
		"\u0001\u0001\u0002\u0001\u0002\u0001\u0003\u0001\u0003\u0001\u0004\u0001"+
		"\u0004\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0003"+
		"\u0005#\b\u0005\u0001\u0006\u0004\u0006&\b\u0006\u000b\u0006\f\u0006\'"+
		"\u0001\u0007\u0004\u0007+\b\u0007\u000b\u0007\f\u0007,\u0001\b\u0004\b"+
		"0\b\b\u000b\b\f\b1\u0001\b\u0001\b\u0000\u0000\t\u0001\u0001\u0003\u0002"+
		"\u0005\u0003\u0007\u0004\t\u0005\u000b\u0006\r\u0007\u000f\b\u0011\t\u0001"+
		"\u0000\u0005\u0003\u0000,,..:;\u0002\u0000ooyy\u0001\u000009\u000e\u0000"+
		"AZaz\u00c1\u00c1\u00c9\u00c9\u00cd\u00cd\u00d1\u00d1\u00d3\u00d3\u00da"+
		"\u00da\u00e1\u00e1\u00e9\u00e9\u00ed\u00ed\u00f1\u00f1\u00f3\u00f3\u00fa"+
		"\u00fa\u0003\u0000\t\n\r\r  8\u0000\u0001\u0001\u0000\u0000\u0000\u0000"+
		"\u0003\u0001\u0000\u0000\u0000\u0000\u0005\u0001\u0000\u0000\u0000\u0000"+
		"\u0007\u0001\u0000\u0000\u0000\u0000\t\u0001\u0000\u0000\u0000\u0000\u000b"+
		"\u0001\u0000\u0000\u0000\u0000\r\u0001\u0000\u0000\u0000\u0000\u000f\u0001"+
		"\u0000\u0000\u0000\u0000\u0011\u0001\u0000\u0000\u0000\u0001\u0013\u0001"+
		"\u0000\u0000\u0000\u0003\u0015\u0001\u0000\u0000\u0000\u0005\u0017\u0001"+
		"\u0000\u0000\u0000\u0007\u0019\u0001\u0000\u0000\u0000\t\u001b\u0001\u0000"+
		"\u0000\u0000\u000b\"\u0001\u0000\u0000\u0000\r%\u0001\u0000\u0000\u0000"+
		"\u000f*\u0001\u0000\u0000\u0000\u0011/\u0001\u0000\u0000\u0000\u0013\u0014"+
		"\u0005\u00a1\u0000\u0000\u0014\u0002\u0001\u0000\u0000\u0000\u0015\u0016"+
		"\u0005!\u0000\u0000\u0016\u0004\u0001\u0000\u0000\u0000\u0017\u0018\u0005"+
		"\u00bf\u0000\u0000\u0018\u0006\u0001\u0000\u0000\u0000\u0019\u001a\u0005"+
		"?\u0000\u0000\u001a\b\u0001\u0000\u0000\u0000\u001b\u001c\u0007\u0000"+
		"\u0000\u0000\u001c\n\u0001\u0000\u0000\u0000\u001d#\u0007\u0001\u0000"+
		"\u0000\u001e\u001f\u0005p\u0000\u0000\u001f \u0005e\u0000\u0000 !\u0005"+
		"r\u0000\u0000!#\u0005o\u0000\u0000\"\u001d\u0001\u0000\u0000\u0000\"\u001e"+
		"\u0001\u0000\u0000\u0000#\f\u0001\u0000\u0000\u0000$&\u0007\u0002\u0000"+
		"\u0000%$\u0001\u0000\u0000\u0000&\'\u0001\u0000\u0000\u0000\'%\u0001\u0000"+
		"\u0000\u0000\'(\u0001\u0000\u0000\u0000(\u000e\u0001\u0000\u0000\u0000"+
		")+\u0007\u0003\u0000\u0000*)\u0001\u0000\u0000\u0000+,\u0001\u0000\u0000"+
		"\u0000,*\u0001\u0000\u0000\u0000,-\u0001\u0000\u0000\u0000-\u0010\u0001"+
		"\u0000\u0000\u0000.0\u0007\u0004\u0000\u0000/.\u0001\u0000\u0000\u0000"+
		"01\u0001\u0000\u0000\u00001/\u0001\u0000\u0000\u000012\u0001\u0000\u0000"+
		"\u000023\u0001\u0000\u0000\u000034\u0006\b\u0000\u00004\u0012\u0001\u0000"+
		"\u0000\u0000\u0005\u0000\"\',1\u0001\u0006\u0000\u0000";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}